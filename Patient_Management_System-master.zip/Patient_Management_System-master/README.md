# Patient_Management_System
Web Health Project for Patient Management System

The Patient Management System has 3 modules:

Patient Registration
Appointment Scheduling
Billing
